export interface Personaje {
  name: string;
  strength: number;
  agility: number;
  intelligence: number;
  life: number;
  stat6: number;
  stat7:number;
  stat8: number;


}
